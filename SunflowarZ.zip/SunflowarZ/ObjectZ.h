#pragma once
class ObjectZ
{
public:

	virtual void useZ();

	virtual void updateZ();

	ObjectZ();
	~ObjectZ();

private:

};

