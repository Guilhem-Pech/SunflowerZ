// pch.cpp : fichier source correspondant à l'en-tête précompilé ; nécessaire au bon déroulement de la compilation

#include "pch.h"

// Vous pouvez en général ignorer ce fichier, mais gardez-le si vous utilisez des en-têtes précompilés.
