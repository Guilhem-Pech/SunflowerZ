#include "pch.h"
#include "ObjectZ.h"


void ObjectZ::useZ()
{
}

void ObjectZ::updateZ()
{
}

ObjectZ::ObjectZ()
{

}


ObjectZ::~ObjectZ()
{
}
